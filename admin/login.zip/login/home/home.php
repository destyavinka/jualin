<?php
session_start();
if (!isset($_SESSION['is_login'])) {
	header('location:../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Home</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	<script src="js/jquery.js"></script>
	<script src="bootstrap/js/bootstrap.min.js"></script>

	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css">

</head>

<body>


	<div class="container bg-info" style="padding-top: 20px; padding-bottom: 20px;">

		<h1>KELOMPOK AMIR SYARIF</h1>
		<h2>Dibuat oleh : </h2>
		<div><a href="https://www.instagram.com/habib_jaddid/">
				<img style="margin:5px" src="instagram.png" width="30" height="30" alt="Instagram">
			</a><a href="https://www.facebook.com/"><img style="margin:5px" src="facebook.png" width="30" height="30" alt="Facebook">
			</a><a href="https://www.youtube.com/c/Habibtvv/"><img style="margin:5px" src="youtube.png" width="30" height="30" alt="YouTube"></a></div>
		<a href="../logout.php" class="btn btn-danger">Keluar</a>

		<h3>Tampil Produk</h3>
	<table border="1" cellpadding="5" cellspacing="0" width="100%">
		<tr>
			<td>No</td>
			<td>Nama Produk</td>
			<td>Harga</td>
			<td>Kuantitas</td>
			<td>Aksi</td>
		</tr>
		<?php
		
		include_once('../db_connect.php');
		$database = new database();

		$i=0;
		$products = $database->productAll();
		while ($product = mysqli_fetch_array($products)) {
		?>
			<tr>
				<td><?php echo $i; ?></td>
				<td><?php echo $product['name']; ?></td>
				<td><?php echo $product['price']; ?></td>
				<td><?php echo $product['quantity']; ?></td>
				<td>
					<a href="product_detail.php?id=<?php echo $product['id'] ?>">Lihat</a>
					<a href="product_edit.php?id=<?php echo $product['id'] ?>">Edit</a>
					<a href="product_delete.php?id=<?php echo $product['id'] ?>">Hapus</a>
				</td>
			</tr>
		<?php $i = $i + 1;
		} ?>
	</table>
	</div>

	
</body>

<script src="http://code.jquery.com/jquery-1.12.0.min.js"></script>
<script src="//cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
<script>
	$(document).ready(function() {
		$('.dtabel').DataTable();
	});
</script>

</html>